package com.example.wetzelproject;

import android.app.Activity;
import android.widget.*;
import android.os.Bundle;
import android.os.Handler;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;

import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.ArrayList;


public class MainActivity extends Activity implements OnClickListener
	{
		private TextView deckNum;
		private TextView cardLabel;
		private TextView suitLabel;
		private TextView countNumber;
		private Button runButton;
		private Button plusButton;
		private Button minusButton;
		private Button countButton;
		private Button resetButton;
		private TextView trueNum;
		private Button autoButton;
		
		private int decks = 1;
		private int count = 0;
		private boolean visible = true;
		private boolean running = false;

		final Handler handler = new Handler();
		
		String[] cards = {"ah", "2h", "3h", "4h", "5h", "6h", "7h", "8h", "9h", "th", "jh", "qh", "kh", "as", "2s", "3s", "4s", "5s", "6s", "7s", "8s", "9s", "ts", "js", "qs", "ks", "ac", "2c", "3c", "4c", "5c", "6c", "7c", "8c", "9c", "tc", "jc", "qc", "kc", "ad", "2d", "3d", "4d", "5d", "6d", "7d", "8d", "9d", "td", "jd", "qd", "kd"};
		String[] suits = {"♠", "♥", "♦", "♣"};

		List<String> cardsList = new ArrayList<String>(Arrays.asList(cards));	
		
		//cardsList.addAll(Arrays.asList(cards));
		
		@Override
		protected void onCreate(Bundle savedInstanceState)
			{
				super.onCreate(savedInstanceState);
				setContentView(R.layout.activity_main);
				
				runButton = (Button) findViewById(R.id.runButton);
				plusButton = (Button) findViewById(R.id.plusButton);
				minusButton = (Button) findViewById(R.id.minusButton);
				deckNum = (TextView) findViewById(R.id.deckNum);
				cardLabel = (TextView) findViewById(R.id.cardLabel);
				suitLabel = (TextView) findViewById(R.id.suitLabel);
				countNumber = (TextView) findViewById(R.id.countNumber);
				countButton = (Button) findViewById(R.id.countButton);
				resetButton = (Button) findViewById(R.id.resetButton);
				trueNum = (TextView) findViewById(R.id.trueNum);
				autoButton = (Button) findViewById(R.id.autoButton);
				
				autoButton.setOnClickListener(this);
				resetButton.setOnClickListener(this);
				countButton.setOnClickListener(this);
				runButton.setOnClickListener(this);
				plusButton.setOnClickListener(this);
				minusButton.setOnClickListener(this);
				
			}

		@Override
		public boolean onCreateOptionsMenu(Menu menu)
			{
				// Inflate the menu; this adds items to the action bar if it is
				// present.
				getMenuInflater().inflate(R.menu.main, menu);
				return true;
			}

		@Override
		public boolean onOptionsItemSelected(MenuItem item)
			{
				// Handle action bar item clicks here. The action bar will
				// automatically handle clicks on the Home/Up button, so long
				// as you specify a parent activity in AndroidManifest.xml.
				int id = item.getItemId();
				if (id == R.id.action_settings)
					{
						return true;
					}
				return super.onOptionsItemSelected(item);
			}

		public void newCard()
			{
				if (cardsList.size() == 0)
					{
						cardLabel.setText("End");
						suitLabel.setText("");
						
					}
				else
					{
					int rand = new Random().nextInt(cardsList.size());
					String card = cardsList.get(rand);
					char cardChar = card.charAt(0);
					char suitChar = card.charAt(1);
					switch (cardChar) 
					{
						case '2':
							cardLabel.setText("2");
							count += 1;
							cardsList.remove(rand);
							trueNum.setText(Integer.toString(count / decks));
							break;
						case '3':
							cardLabel.setText("3");
							count += 1;
							cardsList.remove(rand);
							trueNum.setText(Integer.toString(count / decks));
							break;
						case '4':
							cardLabel.setText("4");
							count += 1;
							cardsList.remove(rand);
							trueNum.setText(Integer.toString(count / decks));
							break;
						case '5':
							cardLabel.setText("5");
							count += 1;
							cardsList.remove(rand);
							trueNum.setText(Integer.toString(count / decks));
							break;
						case '6':
							cardLabel.setText("6");
							count += 1;
							cardsList.remove(rand);
							trueNum.setText(Integer.toString(count / decks));
							break;
						case '7':
							cardLabel.setText("7");
							cardsList.remove(rand);
							trueNum.setText(Integer.toString(count / decks));
							break;
						case '8':
							cardLabel.setText("8");
							cardsList.remove(rand);
							trueNum.setText(Integer.toString(count / decks));
							break;
						case '9':
							cardLabel.setText("9");
							cardsList.remove(rand);
							trueNum.setText(Integer.toString(count / decks));
							break;
						case 't':
							cardLabel.setText("10");
							cardsList.remove(rand);
							count -= 1;
							trueNum.setText(Integer.toString(count / decks));
							break;
						case 'j':
							cardLabel.setText("J");
							cardsList.remove(rand);
							count -= 1;
							trueNum.setText(Integer.toString(count / decks));
							break;
						case 'q':
							cardLabel.setText("Q");
							cardsList.remove(rand);
							count -= 1;
							trueNum.setText(Integer.toString(count / decks));
							break;
						case 'k':
							cardLabel.setText("K");
							count -= 1;
							cardsList.remove(rand);
							trueNum.setText(Integer.toString(count / decks));
							break;
						case 'a':
							cardLabel.setText("A");
							count -= 1;
							cardsList.remove(rand);
							trueNum.setText(Integer.toString(count / decks));
							break;
						}
					switch (suitChar) 
					{
						case ('h'):
							suitLabel.setText(suits[1]);
							break;
						case ('d'):
							suitLabel.setText(suits[2]);
							break;
						case ('c'):
							suitLabel.setText(suits[3]);
							break;
						case ('s'):
							suitLabel.setText(suits[0]);
							break;
					}
					}
				countNumber.setText(Integer.toString(count));
			}
		
		@Override
		public void onClick(View v)
			{
				switch (v.getId()) {
				case R.id.runButton:
					newCard();
					countNumber.setText(Integer.toString(count));
					break;
					
				case R.id.minusButton:
					if (decks > 1)
						{
							decks -= 1;
							deckNum.setText(Integer.toString(decks));
							int size = cardsList.size() - 1;
							if (size > 52)
								{
									for(int i = 0; i < 52; i++)
										{
											cardsList.remove(size);
											size -= 1;
										}
								}
						}
					break;
					
				case R.id.plusButton:
					decks += 1;
					deckNum.setText(Integer.toString(decks));
					cardsList.addAll(Arrays.asList(cards));
					break;
					
				case R.id.countButton:
					if (visible == true)
						{
							countNumber.setVisibility(View.GONE);
							trueNum.setVisibility(View.GONE);
							countButton.setText("Show Count");
							visible = false;
						}
					else
						{
							countNumber.setVisibility(View.VISIBLE);
							trueNum.setVisibility(View.VISIBLE);
							countButton.setText("Hide Count");
							visible = true;
						}
					break;
					
				case R.id.resetButton:
					cardLabel.setText("Card");
					suitLabel.setText("Suit");
					cardsList = new ArrayList<String>(Arrays.asList(cards));
					decks = 1;
					deckNum.setText(Integer.toString(decks));
					count = 0;
					countNumber.setText(Integer.toString(count));
					trueNum.setText(Integer.toString(count / decks));
					handler.removeCallbacksAndMessages(null);
					autoButton.setText("Auto Run");
					running = false;
					
					break;
				
				case R.id.autoButton:
					if (running == true)
						{
							autoButton.setText("Auto Run");
							handler.removeCallbacksAndMessages(null);
							running = false;
						}
					else if (running == false)
						{
							for (int i = 0; i < cardsList.size(); i++)
								{
									handler.postDelayed(new Runnable(){
										public void run(){
											newCard();
										}
									},  750 * i);
								}
							if (cardsList.size() == 0)
								{
									autoButton.setText("Auto Run");
									handler.removeCallbacksAndMessages(null);
									running = false;
								}
							else
								{
									running = true;
									autoButton.setText("Stop Run");
								}
						}
					break;
				default:
					break;
			}
		}

	}
